﻿ | FileName                  | Status | Component | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|-----------|----------|----------------|-------------|-------------|---------------|-------------|
 | onnxruntime.dll           | Pass   | Sign      | 10.7MB   | 64.55          | 1.51        | 0.34        | 62.65         | 0           | 
 | time_providers_shared.dll | Pass   | Sign      | 11.5KB   | 85.65          | 0.69        | 0.39        | 83.75         | 0           | 
